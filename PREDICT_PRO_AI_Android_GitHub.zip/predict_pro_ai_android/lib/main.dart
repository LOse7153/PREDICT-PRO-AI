import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

const bg = Color(0xFF070B14);
const panel = Color(0xFF101827);
const panel2 = Color(0xFF151F31);
const accent = Color(0xFF31E981);
const danger = Color(0xFFFF5577);
const muted = Color(0xFF91A0B5);

void main() => runApp(const PredictProAiApp());

class PredictProAiApp extends StatelessWidget {
  const PredictProAiApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'PREDICT PRO AI',
        theme: ThemeData.dark(useMaterial3: true).copyWith(
          scaffoldBackgroundColor: bg,
          colorScheme: ColorScheme.fromSeed(seedColor: accent, brightness: Brightness.dark),
          cardColor: panel,
        ),
        home: const HomePage(),
      );
}

class ApiService {
  final String token;
  const ApiService(this.token);

  Future<dynamic> get(String path, [Map<String, String>? params]) async {
    final uri = Uri.https('api.football-data.org', '/v4$path', params ?? {});
    final r = await http.get(uri, headers: {'X-Auth-Token': token, 'Accept': 'application/json'});
    dynamic body;
    try { body = jsonDecode(r.body); } catch (_) { body = {}; }
    if (r.statusCode >= 400) {
      throw Exception(body is Map && body['message'] != null ? body['message'] : 'Erreur API ${r.statusCode}');
    }
    return body;
  }

  Future<List<Map<String, dynamic>>> matchesForDate(DateTime d) async {
    final s = _date(d);
    final data = await get('/matches', {'dateFrom': s, 'dateTo': s});
    return List<Map<String, dynamic>>.from(data['matches'] ?? []);
  }

  Future<List<Map<String, dynamic>>> liveMatches() async {
    final data = await get('/matches', {'status': 'LIVE'});
    final list = List<Map<String, dynamic>>.from(data['matches'] ?? []);
    if (list.isNotEmpty) return list;
    final inPlay = await get('/matches', {'status': 'IN_PLAY'});
    final paused = await get('/matches', {'status': 'PAUSED'});
    return [...List<Map<String, dynamic>>.from(inPlay['matches'] ?? []), ...List<Map<String, dynamic>>.from(paused['matches'] ?? [])];
  }

  Future<Map<String, dynamic>> match(int id) async => Map<String, dynamic>.from(await get('/matches/$id'));

  Future<List<Map<String, dynamic>>> history(int id) async {
    final data = await get('/teams/$id/matches', {'status': 'FINISHED', 'limit': '50'});
    return List<Map<String, dynamic>>.from(data['matches'] ?? []);
  }

  static String _date(DateTime d) => '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
}

class PredictionEngine {
  static double avg(List<double> v, [double fallback = 1.25]) => v.isEmpty ? fallback : v.reduce((a,b)=>a+b)/v.length;
  static double poisson(int k, double lambda) => exp(-lambda) * pow(max(lambda, 0.03), k) / _factorial(k);
  static int _factorial(int n) => n <= 1 ? 1 : List.generate(n, (i)=>i+1).reduce((a,b)=>a*b);

  static Map<String, double> normalize(Map<String, double> x) {
    final s = x.values.fold<double>(0, (a,b)=>a+b);
    return s == 0 ? x : x.map((k,v)=>MapEntry(k,v/s));
  }

  static Map<String, double> teamFeatures(List<Map<String,dynamic>> ms, int id) {
    final gf=<double>[], ga=<double>[], hgf=<double>[], hga=<double>[], agf=<double>[], aga=<double>[];
    for (final m in ms) {
      final ft = (m['score']?['fullTime']) as Map?;
      final hs = ft?['home'], aw = ft?['away'];
      if (hs is! num || aw is! num) continue;
      if (m['homeTeam']?['id'] == id) { gf.add(hs.toDouble()); ga.add(aw.toDouble()); hgf.add(hs.toDouble()); hga.add(aw.toDouble()); }
      else if (m['awayTeam']?['id'] == id) { gf.add(aw.toDouble()); ga.add(hs.toDouble()); agf.add(aw.toDouble()); aga.add(hs.toDouble()); }
    }
    final g=avg(gf), c=avg(ga);
    return {'gf':g,'ga':c,'home_gf':avg(hgf,g),'home_ga':avg(hga,c),'away_gf':avg(agf,g),'away_ga':avg(aga,c),'sample':gf.length.toDouble()};
  }

  static Map<String, double> halfFeatures(List<Map<String,dynamic>> ms, int id, {required bool firstHalf}) {
    final gf=<double>[], ga=<double>[];
    for (final m in ms) {
      final ft = m['score']?['fullTime'];
      final ht = m['score']?['halfTime'];
      final hs = ft?['home'], aw = ft?['away'];
      final hth = ht?['home'], hta = ht?['away'];
      if (hs is! num || aw is! num || hth is! num || hta is! num) continue;
      final home = m['homeTeam']?['id'] == id;
      final away = m['awayTeam']?['id'] == id;
      if (!home && !away) continue;
      double teamFor, teamAgainst;
      if (firstHalf) {
        teamFor = home ? hth.toDouble() : hta.toDouble();
        teamAgainst = home ? hta.toDouble() : hth.toDouble();
      } else {
        final home2 = max(0.0, hs.toDouble() - hth.toDouble());
        final away2 = max(0.0, aw.toDouble() - hta.toDouble());
        teamFor = home ? home2 : away2;
        teamAgainst = home ? away2 : home2;
      }
      gf.add(teamFor); ga.add(teamAgainst);
    }
    return {'gf':avg(gf, .55),'ga':avg(ga, .55),'sample':gf.length.toDouble()};
  }

  static Map<String,double> statFeatures(List<Map<String,dynamic>> ms, int id, String key) {
    final vals=<double>[];
    for(final m in ms){
      final stats=m['homeTeam']?['id']==id ? m['homeTeam']?['statistics'] : m['awayTeam']?['statistics'];
      final v=stats?[key];
      if(v is num) vals.add(v.toDouble());
    }
    return {'avg':avg(vals,0.0),'sample':vals.length.toDouble()};
  }

  static Map<String,dynamic> statAnalysis(Map<String,dynamic> match,List<Map<String,dynamic>> hh,List<Map<String,dynamic>> aa,String key,String label) {
    final hid=match['homeTeam']['id'] as int, aid=match['awayTeam']['id'] as int;
    final hf=statFeatures(hh,hid,key), af=statFeatures(aa,aid,key);
    double home=(hf['avg']!+af['avg']!)/2;
    double away=(af['avg']!+hf['avg']!)/2;
    final live=['LIVE','IN_PLAY','PAUSED'].contains('${match['status']}');
    final hs=match['homeTeam']?['statistics']?[key];
    final as=match['awayTeam']?['statistics']?[key];
    double currentHome=hs is num ? hs.toDouble() : 0.0;
    double currentAway=as is num ? as.toDouble() : 0.0;
    if(live && (hs is num || as is num)) {
      final minute=((match['minute'] as num?)?.toDouble() ?? 0).clamp(1,90).toDouble();
      final factor=(90/minute).clamp(1,4).toDouble();
      home=max(0.05,(home-currentHome)*((90-minute)/90));
      away=max(0.05,(away-currentAway)*((90-minute)/90));
      return {'label':label,'homeExpected':currentHome+home,'awayExpected':currentAway+away,'currentHome':currentHome,'currentAway':currentAway,'live':true,'homeSample':hf['sample'],'awaySample':af['sample'],'totalExpected':currentHome+currentAway+home+away,'leader':currentHome>currentAway?'home':currentAway>currentHome?'away':'draw'};
    }
    return {'label':label,'homeExpected':home,'awayExpected':away,'currentHome':0.0,'currentAway':0.0,'live':false,'homeSample':hf['sample'],'awaySample':af['sample'],'totalExpected':home+away,'leader':home>away?'home':away>home?'away':'draw'};
  }

  static Map<String, dynamic> halfPrediction({required double lh, required double la, int baseH=0, int baseA=0}) {
    final grid=scoreGrid(lh,la,maxGoals:6,baseH:baseH,baseA:baseA);
    final p=oneXTwo(grid);
    final sorted=grid.entries.toList()..sort((a,b)=>b.value.compareTo(a.value));
    final best=p.entries.reduce((a,b)=>a.value>b.value?a:b).key;
    return {'probabilities':p,'scores':sorted.take(3).map((e)=>{'score':e.key,'probability':e.value}).toList(),'best':best};
  }

  static Map<String, dynamic> halfAnalyses(Map<String,dynamic> match,List<Map<String,dynamic>> hh,List<Map<String,dynamic>> aa) {
    final status='${match['status']}';
    final live=['LIVE','IN_PLAY','PAUSED'].contains(status);
    final h1h=halfFeatures(hh,match['homeTeam']['id'] as int,firstHalf:true);
    final h1a=halfFeatures(aa,match['awayTeam']['id'] as int,firstHalf:true);
    final h2h=halfFeatures(hh,match['homeTeam']['id'] as int,firstHalf:false);
    final h2a=halfFeatures(aa,match['awayTeam']['id'] as int,firstHalf:false);
    var firstHome=max(.05,(h1h['gf']!+h1a['ga']!)/2);
    var firstAway=max(.05,(h1a['gf']!+h1h['ga']!)/2);
    var secondHome=max(.05,(h2h['gf']!+h2a['ga']!)/2);
    var secondAway=max(.05,(h2a['gf']!+h2h['ga']!)/2);
    var firstBaseH=0, firstBaseA=0, secondBaseH=0, secondBaseA=0;
    final score=match['score'] as Map?;
    final ft=score?['fullTime'] as Map?;
    final ht=score?['halfTime'] as Map?;
    if (live && ft != null && ft['home'] is num && ft['away'] is num) {
      final minute=(match['minute'] as num?)?.toDouble() ?? 0;
      if (minute > 45 && ht != null && ht['home'] is num && ht['away'] is num) {
        firstBaseH=(ht['home'] as num).toInt();
        firstBaseA=(ht['away'] as num).toInt();
        secondBaseH=max(0,(ft['home'] as num).toInt()-firstBaseH);
        secondBaseA=max(0,(ft['away'] as num).toInt()-firstBaseA);
        final remaining=(1-max(0,min(90,minute))/90).clamp(.05,1).toDouble();
        secondHome*=remaining; secondAway*=remaining;
      }
    }
    final first=halfPrediction(lh:firstHome,la:firstAway,baseH:firstBaseH,baseA:firstBaseA);
    final second=halfPrediction(lh:secondHome,la:secondAway,baseH:secondBaseH,baseA:secondBaseA);
    return {'first':first,'second':second,'expected':{'first':{'home':firstHome,'away':firstAway},'second':{'home':secondHome,'away':secondAway}},'samples':{'first_home':h1h['sample'],'first_away':h1a['sample'],'second_home':h2h['sample'],'second_away':h2a['sample']}};
  }

  static double elo(List<Map<String,dynamic>> ms, int id) {
    var rating=1500.0;
    final ordered=[...ms]..sort((a,b)=>('${a['utcDate']}' ).compareTo('${b['utcDate']}'));
    for(final m in ordered){
      final ft=m['score']?['fullTime']; final hs=ft?['home'], aw=ft?['away'];
      if(hs is! num || aw is! num) continue;
      final home=m['homeTeam']?['id']==id, away=m['awayTeam']?['id']==id;
      if(!home && !away) continue;
      final actual=home ? (hs>aw?1.0:hs==aw?.5:0.0) : (aw>hs?1.0:hs==aw?.5:0.0);
      final expected=1/(1+pow(10,(1500-rating)/400));
      rating += 24*(actual-expected);
    }
    return rating;
  }

  static double dcTau(int h,int a,double lh,double la,[double rho=-.08]) {
    if(h==0&&a==0) return max(0,1-lh*la*rho);
    if(h==0&&a==1) return max(0,1+lh*rho);
    if(h==1&&a==0) return max(0,1+la*rho);
    if(h==1&&a==1) return max(0,1-rho);
    return 1;
  }

  static Map<String,double> scoreGrid(double lh,double la,{int maxGoals=8,int baseH=0,int baseA=0}) {
    final g=<String,double>{};
    for(int h=0;h<=maxGoals;h++) for(int a=0;a<=maxGoals;a++) {
      final p=poisson(h,lh)*poisson(a,la)*dcTau(h,a,lh,la);
      g['${h+baseH}-${a+baseA}']=p;
    }
    final s=g.values.fold<double>(0,(a,b)=>a+b);
    return g.map((k,v)=>MapEntry(k,v/s));
  }

  static Map<String,double> oneXTwo(Map<String,double> grid) {
    var h=0.0,d=0.0,a=0.0;
    for(final e in grid.entries){
      final p=e.key.split('-'); final x=int.parse(p[0]), y=int.parse(p[1]);
      if(x>y) h+=e.value; else if(x==y) d+=e.value; else a+=e.value;
    }
    return normalize({'home':h,'draw':d,'away':a});
  }

  static Map<String,double> monteCarlo(Map<String,double> grid,{int simulations=20000}) {
    final rng=Random(42); var h=0,d=0,a=0;
    final entries=grid.entries.toList();
    for(var i=0;i<simulations;i++){
      final r=rng.nextDouble(); var acc=0.0;
      for(final e in entries){
        acc+=e.value;
        if(r<=acc){
          final p=e.key.split('-'); final x=int.parse(p[0]), y=int.parse(p[1]);
          if(x>y) h++; else if(x==y) d++; else a++;
          break;
        }
      }
    }
    return {'home':h/simulations,'draw':d/simulations,'away':a/simulations};
  }

  static Future<Map<String,dynamic>> predict(Map<String,dynamic> match,List<Map<String,dynamic>> hh,List<Map<String,dynamic>> aa) async {
    final home=match['homeTeam'] as Map; final away=match['awayTeam'] as Map;
    final hid=home['id'] as int, aid=away['id'] as int;
    final hf=teamFeatures(hh,hid), af=teamFeatures(aa,aid);
    var lh=((hf['home_gf']!+af['away_ga']!)/2)*1.07;
    var la=((af['away_gf']!+hf['home_ga']!)/2)*.95;
    final status='${match['status']}';
    var baseH=0,baseA=0;
    if(['LIVE','IN_PLAY','PAUSED'].contains(status)){
      final score=match['score']?['fullTime'];
      baseH=(score?['home'] as num? ?? 0).toInt(); baseA=(score?['away'] as num? ?? 0).toInt();
      final minute=(match['minute'] as num?)?.toDouble() ?? 0;
      final remaining=(1-max(0,min(90,minute))/90).clamp(.05,1).toDouble();
      lh*=remaining; la*=remaining;
    }
    lh=max(.10,lh); la=max(.10,la);
    final grid=scoreGrid(lh,la,baseH:baseH,baseA:baseA);
    final pdc=oneXTwo(grid);
    final hs=hf['gf']!/max(.25,hf['ga']!), as=af['gf']!/max(.25,af['ga']!);
    final form=normalize({'home':1+.30*hs,'draw':1.0,'away':1+.30*as});
    final eh=elo(hh,hid), ea=elo(aa,aid);
    final eloHome=1/(1+pow(10,(ea-(eh+55))/400));
    final elo=normalize({'home':eloHome,'draw':.26,'away':1-eloHome});
    final mc=monteCarlo(grid);
    final consensus=normalize({
      'home':.45*pdc['home']!+.18*form['home']!+.17*elo['home']!+.20*mc['home']!,
      'draw':.45*pdc['draw']!+.18*form['draw']!+.17*elo['draw']!+.20*mc['draw']!,
      'away':.45*pdc['away']!+.18*form['away']!+.17*elo['away']!+.20*mc['away']!,
    });
    final sorted=grid.entries.toList()..sort((x,y)=>y.value.compareTo(x.value));
    final best=consensus.entries.reduce((a,b)=>a.value>b.value?a:b).key;
    final halves=halfAnalyses(match,hh,aa);
    final stats={'yellow':statAnalysis(match,hh,aa,'yellow_cards','Cartons jaunes'),'corners':statAnalysis(match,hh,aa,'corner_kicks','Corners'),'shotsOnTarget':statAnalysis(match,hh,aa,'shots_on_goal','Tirs cadrés')};
    return {'consensus':consensus,'models':{'poisson_dixon_coles':pdc,'forme':form,'elo':elo,'monte_carlo':mc},'exact_scores':sorted.take(5).map((e)=>{'score':e.key,'probability':e.value}).toList(),'expected_goals':{'home':lh,'away':la},'halves':halves,'stats':stats,'best':best,'confidence':consensus[best],'samples':{'home':hf['sample'],'away':af['sample']}};
  }
}


class OpenAiService {
  final String apiKey;
  const OpenAiService(this.apiKey);

  Future<String> analyseMatch({required Map<String, dynamic> match, required Map<String, dynamic> prediction}) async {
    final home = match['homeTeam']?['name'] ?? 'Domicile';
    final away = match['awayTeam']?['name'] ?? 'Extérieur';
    final competition = match['competition']?['name'] ?? 'Compétition inconnue';
    final status = match['status'] ?? 'UNKNOWN';
    final prompt = '''Tu es l’analyste IA de l’application PREDICT PRO AI.
Analyse UNIQUEMENT les données statistiques fournies ci-dessous. N’invente aucune statistique et ne présente jamais une prédiction comme certaine.
Réponds en français, de façon claire et courte, avec ces rubriques :
1) Lecture du match
2) Forces/faiblesses visibles dans les données
3) Scénario probable
4) Niveau de confiance et limites
5) Conclusion prudente

Match : $home vs $away
Compétition : $competition
Statut : $status
Données du moteur statistique :
${jsonEncode(prediction)}

Important : le score exact est probabiliste et aucune garantie de gain ne doit être donnée.''';

    final r = await http.post(
      Uri.parse('https://api.openai.com/v1/responses'),
      headers: {
        'Authorization': 'Bearer $apiKey',
        'Content-Type': 'application/json',
      },
      body: jsonEncode({
        'model': 'gpt-5.6-luna',
        'input': prompt,
        'store': false,
      }),
    );

    dynamic body;
    try { body = jsonDecode(r.body); } catch (_) { body = {}; }
    if (r.statusCode >= 400) {
      final msg = body is Map && body['error'] is Map
          ? body['error']['message']
          : 'Erreur IA HTTP ${r.statusCode}';
      throw Exception(msg ?? 'Erreur IA HTTP ${r.statusCode}');
    }
    if (body is Map && body['output_text'] is String && (body['output_text'] as String).trim().isNotEmpty) {
      return body['output_text'].toString().trim();
    }
    if (body is Map && body['output'] is List) {
      final parts = <String>[];
      for (final item in body['output']) {
        if (item is Map && item['content'] is List) {
          for (final c in item['content']) {
            if (c is Map && c['text'] is String) parts.add(c['text'].toString());
          }
        }
      }
      final text = parts.join('\n').trim();
      if (text.isNotEmpty) return text;
    }
    throw Exception('Réponse IA vide ou non reconnue.');
  }
  Future<List<Map<String,dynamic>>> tipsterReview(List<Map<String,dynamic>> candidates) async {
    final prompt = '''Tu es IA TIPSTER de PREDICT PRO AI. Fais une seconde lecture prudente des candidats. Utilise uniquement les données fournies; n'invente ni cote, ni blessure, ni actualité. Tu peux confirmer ou remplacer par PASS. Ne promets jamais un gain. Réponds uniquement avec un JSON: {"picks":[{"match":"Equipe A vs Equipe B","pick":"1|X2|1X|2|PASS","confidence":0.0,"reason":"courte raison"}]}.

Candidats réels calculés par PREDICT PRO AI:
${jsonEncode(candidates)}''';
    final r=await http.post(Uri.parse('https://api.openai.com/v1/responses'),headers:{'Authorization':'Bearer $apiKey','Content-Type':'application/json'},body:jsonEncode({'model':'gpt-5.6-luna','input':prompt,'store':false}));
    dynamic body; try{body=jsonDecode(r.body);}catch(_){body={};}
    if(r.statusCode>=400) throw Exception(body is Map && body['error'] is Map ? body['error']['message'] : 'Erreur IA TIPSTER HTTP ${r.statusCode}');
    String text='';
    if(body is Map && body['output_text'] is String) text=body['output_text'].toString().trim();
    if(text.isEmpty && body is Map && body['output'] is List){ final parts=<String>[]; for(final item in body['output']){if(item is Map && item['content'] is List){for(final c in item['content']){if(c is Map && c['text'] is String) parts.add(c['text'].toString());}}} text=parts.join('').trim(); }
    if(text.isEmpty) throw Exception('Réponse IA TIPSTER vide.');
    final cleaned=text.replaceFirst(RegExp(r'^```json\s*'), '').replaceFirst(RegExp(r'\s*```$'), '').trim();
    final decoded=jsonDecode(cleaned);
    return List<Map<String,dynamic>>.from((decoded['picks'] as List).map((e)=>Map<String,dynamic>.from(e)));
  }

}


class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage> {
  final storage=const FlutterSecureStorage();
  String? token; ApiService? api; DateTime selected=DateTime.now();
  int tab=0; bool loading=false; String error=''; List<Map<String,dynamic>> matches=[]; String query=''; bool tipsterLoading=false; List<Map<String,dynamic>> tipsterPicks=[]; String tipsterError='';
  Timer? timer; int resolved=0; int analysed=0; DateTime? dataFetchedAt;

  @override void initState(){super.initState(); _init();}
  @override void dispose(){timer?.cancel();super.dispose();}
  Future<void> _init() async { token=await storage.read(key:'football_token'); if(token!=null&&token!.isNotEmpty){api=ApiService(token!); await _loadDate(); _startTimer();} else {WidgetsBinding.instance.addPostFrameCallback((_){_tokenDialog(first:true);});} }
  void _startTimer(){timer?.cancel(); timer=Timer.periodic(const Duration(seconds:30),(_){if(tab==1 && api!=null) _loadLive();});}
  Future<void> _tokenDialog({bool first=false}) async {
    final c=TextEditingController(text:token??'');
    final value=await showDialog<String>(context:context,barrierDismissible:!first,builder:(ctx)=>AlertDialog(
      title:const Text('Connexion aux données réelles'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[const Text('Entre ton token football-data.org. Il est stocké localement dans le coffre sécurisé Android.'),const SizedBox(height:12),TextField(controller:c,obscureText:true,decoration:const InputDecoration(labelText:'Token API',border:OutlineInputBorder()))]),
      actions:[if(!first)TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Annuler')),FilledButton(onPressed:()=>Navigator.pop(ctx,c.text.trim()),child:const Text('Connecter'))],
    ));
    if(value==null||value.isEmpty){if(first)setState(()=>error='Token API requis pour charger les matchs réels.');return;}
    await storage.write(key:'football_token',value:value); setState(()=>token=value); api=ApiService(value); await _loadDate(); _startTimer();
  }

  Future<void> _aiKeyDialog() async {
    final current = await storage.read(key: 'openai_api_key') ?? '';
    final c = TextEditingController(text: current);
    final value = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Activer l’IA PREDICT PRO AI'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Entre ta clé API OpenAI. Elle est stockée localement dans le coffre sécurisé Android.'),
          const SizedBox(height: 10),
          const Text('Pour une application publique, la clé devrait plutôt rester sur un serveur.', style: TextStyle(color: muted, fontSize: 12)),
          const SizedBox(height: 12),
          TextField(controller: c, obscureText: true, decoration: const InputDecoration(labelText: 'Clé API OpenAI', border: OutlineInputBorder())),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          TextButton(onPressed: () => Navigator.pop(ctx, ''), child: const Text('Désactiver')),
          FilledButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: const Text('Enregistrer')),
        ],
      ),
    );
    if (value == null) return;
    if (value.isEmpty) {
      await storage.delete(key: 'openai_api_key');
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('IA désactivée sur ce téléphone.')));
    } else {
      await storage.write(key: 'openai_api_key', value: value);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('IA PREDICT PRO AI activée.')));
    }
  }

  Future<void> _loadDate() async { if(api==null)return; setState((){loading=true;error='';}); try{matches=await api!.matchesForDate(selected); dataFetchedAt=DateTime.now().toUtc(); }catch(e){error=e.toString();}finally{if(mounted)setState(()=>loading=false);} }
  Future<void> _loadLive() async { if(api==null)return; setState((){loading=true;error='';}); try{matches=await api!.liveMatches(); dataFetchedAt=DateTime.now().toUtc(); }catch(e){error=e.toString();}finally{if(mounted)setState(()=>loading=false);} }
  List<Map<String,dynamic>> get filtered => matches.where((m){final s='${m['homeTeam']?['name']} ${m['awayTeam']?['name']} ${m['competition']?['name']}'.toLowerCase();return s.contains(query.toLowerCase());}).toList();

  @override Widget build(BuildContext context){
    return Scaffold(appBar:AppBar(backgroundColor:bg,title:Row(children:[Container(width:36,height:36,decoration:BoxDecoration(color:accent,borderRadius:BorderRadius.circular(10)),child:const Icon(Icons.insights,color:bg)),const SizedBox(width:10),const Text('PREDICT PRO AI',style:TextStyle(fontWeight:FontWeight.w800))]),actions:[IconButton(onPressed:()=>_aiKeyDialog(),icon:const Icon(Icons.auto_awesome)),IconButton(onPressed:()=>_tokenDialog(),icon:const Icon(Icons.key)),]),
      body:IndexedStack(index:tab,children:[_home(),_live(),_tipster(),_performance(),_virtual()]),
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),backgroundColor:panel,destinations:const [NavigationDestination(icon:Icon(Icons.sports_soccer),label:'Matchs'),NavigationDestination(icon:Icon(Icons.flash_on),label:'LIVE'),NavigationDestination(icon:Icon(Icons.psychology),label:'TIPSTER'),NavigationDestination(icon:Icon(Icons.bar_chart),label:'Performance'),NavigationDestination(icon:Icon(Icons.smart_toy),label:'Virtuel')]),
    );
  }

  Widget _home()=>RefreshIndicator(onRefresh:_loadDate,child:ListView(padding:const EdgeInsets.all(16),children:[_hero(),const SizedBox(height:14),Row(children:[Expanded(child:FilledButton.icon(onPressed:()async{final d=await showDatePicker(context:context,initialDate:selected,firstDate:DateTime(2024),lastDate:DateTime(2035),builder:(c,w)=>Theme(data:Theme.of(c).copyWith(colorScheme:ColorScheme.fromSeed(seedColor:accent,brightness:Brightness.dark)),child:w!));if(d!=null){setState(()=>selected=d);await _loadDate();}},icon:const Icon(Icons.calendar_month),label:Text(_fmt(selected)))),const SizedBox(width:10),IconButton.filled(onPressed:_loadDate,icon:const Icon(Icons.refresh))]),const SizedBox(height:12),TextField(onChanged:(v)=>setState(()=>query=v),decoration:const InputDecoration(prefixIcon:Icon(Icons.search),hintText:'Rechercher une équipe ou compétition',border:OutlineInputBorder())),const SizedBox(height:12),if(loading)const Center(child:Padding(padding:EdgeInsets.all(30),child:CircularProgressIndicator())),if(error.isNotEmpty)_error(error),...filtered.map(_matchCard),if(!loading&&filtered.isEmpty)_empty()]));

  Widget _hero()=>Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFF12233A),Color(0xFF0C1727)]),borderRadius:BorderRadius.circular(22),border:Border.all(color:accent.withOpacity(.22))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('PRÉDICTIONS FOOTBALL',style:TextStyle(color:accent,fontWeight:FontWeight.w800,letterSpacing:1.2)),const SizedBox(height:6),const Text('Données réelles • modèles statistiques • consensus',style:TextStyle(fontSize:20,fontWeight:FontWeight.w800)),const SizedBox(height:8),Text('Aucun score n’est codé en dur. Les probabilités sont recalculées sur les données reçues du fournisseur.',style:TextStyle(color:muted)), if(dataFetchedAt!=null) ...[const SizedBox(height:6), Text('Données reçues : ${dataFetchedAt!.toLocal().toString().substring(0,19)}',style:const TextStyle(color:muted,fontSize:11))]]));

  Widget _matchCard(Map<String,dynamic> m){final live=['LIVE','IN_PLAY','PAUSED'].contains('${m['status']}'); final ft=m['score']?['fullTime']; final hs=ft?['home'],as=ft?['away'];return Card(margin:const EdgeInsets.only(bottom:10),child:InkWell(borderRadius:BorderRadius.circular(14),onTap:()=>_analyse(m),child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${m['competition']?['name']??'Compétition'} • ${_shortDate(m['utcDate'])}',style:const TextStyle(color:muted,fontSize:12)),const SizedBox(height:8),Row(children:[Expanded(child:Text('${m['homeTeam']?['name']??'Domicile'}',style:const TextStyle(fontWeight:FontWeight.w700))),const Text('VS',style:TextStyle(color:muted)),Expanded(child:Text('${m['awayTeam']?['name']??'Extérieur'}',textAlign:TextAlign.right,style:const TextStyle(fontWeight:FontWeight.w700)))]),const SizedBox(height:8),Row(children:[Icon(live?Icons.circle:Icons.schedule,size:12,color:live?danger:muted),const SizedBox(width:5),Text(live?' LIVE ${m['minute']??''}':' ${m['status']??''}',style:TextStyle(color:live?danger:muted)),const Spacer(),Text(hs is num?'$hs - $as':'À venir',style:const TextStyle(fontWeight:FontWeight.w800))])]))));}

  Widget _live()=>RefreshIndicator(onRefresh:_loadLive,child:ListView(padding:const EdgeInsets.all(16),children:[Row(children:[const Expanded(child:Text('Matchs en direct',style:TextStyle(fontSize:24,fontWeight:FontWeight.w800))),IconButton.filled(onPressed:_loadLive,icon:const Icon(Icons.refresh))]),const SizedBox(height:6),const Text('Actualisation automatique toutes les 30 secondes.',style:TextStyle(color:muted)),const SizedBox(height:14),if(loading)const Center(child:CircularProgressIndicator()),if(error.isNotEmpty)_error(error),...matches.map(_matchCard),if(!loading&&matches.isEmpty)_empty('Aucun match LIVE disponible avec ton accès API.')]);

  Future<void> _loadTipster() async {
    if(api==null) return;
    setState(() { tipsterLoading=true; tipsterError=''; tipsterPicks=[]; });
    try {
      final source = matches.isNotEmpty ? matches : await api!.matchesForDate(selected);
      dataFetchedAt ??= DateTime.now().toUtc();
      final upcoming = source.where((m) => !['FINISHED','POSTPONED','CANCELLED'].contains('${m['status']}')).take(10).toList();
      final candidates=<Map<String,dynamic>>[];
      for(final m in upcoming) {
        try {
          final hid=m['homeTeam']?['id']; final aid=m['awayTeam']?['id'];
          if(hid is! int || aid is! int) continue;
          final hh=await api!.history(hid); final aa=await api!.history(aid);
          final r=await PredictionEngine.predict(m,hh,aa);
          final c=Map<String,dynamic>.from(r['consensus']);
          final h=(c['home'] as num).toDouble(), d=(c['draw'] as num).toDouble(), a=(c['away'] as num).toDouble();
          String pick, type; double probability;
          if(h+d>=.72 && h+d>=a) { pick='1X'; type='Double chance'; probability=h+d; }
          else if(d+a>=.72 && d+a>=h) { pick='X2'; type='Double chance'; probability=d+a; }
          else if(h>=.58) { pick='1'; type='Victoire domicile'; probability=h; }
          else if(a>=.58) { pick='2'; type='Victoire extérieur'; probability=a; }
          else { pick='PASS'; type='Pas de sélection'; probability=max(h,max(d,a)); }
          final risk = probability>=.78 ? 'Faible' : probability>=.68 ? 'Modéré' : probability>=.58 ? 'Élevé' : 'Très élevé';
          candidates.add({'match':m,'pick':pick,'type':type,'probability':probability,'risk':risk,'prediction':r});
        } catch (_) {}
      }
      candidates.sort((x,y)=>(y['probability'] as double).compareTo(x['probability'] as double));
      final key = await storage.read(key: 'openai_api_key');
      if(key != null && key.isNotEmpty && candidates.isNotEmpty) {
        try {
          final shortlist = candidates.take(8).map((x) {
            final m=Map<String,dynamic>.from(x['match']);
            return {'match':'${m['homeTeam']?['name']} vs ${m['awayTeam']?['name']}','competition':m['competition']?['name'],'pick':x['pick'],'probability':x['probability'],'risk':x['risk'],'model':x['prediction']};
          }).toList();
          final review = await OpenAiService(key).tipsterReview(shortlist);
          final byMatch=<String,Map<String,dynamic>>{};
          for(final c in candidates) { final m=Map<String,dynamic>.from(c['match']); byMatch['${m['homeTeam']?['name']} vs ${m['awayTeam']?['name']}']=c; }
          for(final r in review) { final name='${r['match'] ?? ''}'; final base=byMatch[name]; if(base!=null){base['ai_pick']=r['pick']; base['ai_reason']=r['reason']; base['ai_confidence']=r['confidence'];} }
        } catch (_) {}
      }
      if(mounted) setState(() { tipsterPicks=candidates; tipsterLoading=false; });
    } catch(e) {
      if(mounted) setState(() { tipsterError=e.toString(); tipsterLoading=false; });
    }
  }

  Widget _tipster()=>RefreshIndicator(onRefresh:_loadTipster,child:ListView(padding:const EdgeInsets.all(16),children:[
    Row(children:[const Expanded(child:Text('IA TIPSTER',style:TextStyle(fontSize:24,fontWeight:FontWeight.w800))),IconButton.filled(onPressed:_loadTipster,icon:const Icon(Icons.refresh))]),
    const SizedBox(height:6),
    const Text('Sélections calculées à partir des données réelles et du consensus PREDICT PRO AI. Aucun pari n’est garanti.',style:TextStyle(color:muted)),
    const SizedBox(height:14),
    Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(18),border:Border.all(color:accent.withOpacity(.22))),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[Icon(Icons.psychology,color:accent),SizedBox(width:8),Text('TIPSTER PRUDENT',style:TextStyle(color:accent,fontWeight:FontWeight.w800))]),
      SizedBox(height:8),Text('Le système privilégie les doubles chances quand elles dépassent le seuil calculé, et peut afficher PASS lorsqu’aucune sélection n’est assez solide.',style:TextStyle(color:muted))
    ])),
    const SizedBox(height:14),
    if(tipsterLoading)const Center(child:Padding(padding:EdgeInsets.all(28),child:CircularProgressIndicator())),
    if(tipsterError.isNotEmpty)_error(tipsterError),
    ...tipsterPicks.map(_tipsterCard),
    if(!tipsterLoading&&tipsterPicks.isEmpty)Padding(padding:const EdgeInsets.all(28),child:Center(child:Column(children:[const Icon(Icons.psychology_outlined,size:44,color:muted),const SizedBox(height:10),const Text('Appuie sur actualiser pour analyser les matchs.',textAlign:TextAlign.center,style:TextStyle(color:muted))])))
  ]));

  Widget _tipsterCard(Map<String,dynamic> x){
    final m=Map<String,dynamic>.from(x['match']);
    final p=(x['probability'] as double)*100;
    final pass=x['pick']=='PASS';
    return Card(margin:const EdgeInsets.only(bottom:10),child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text('${m['competition']?['name']??'Compétition'} • ${_shortDate(m['utcDate'])}',style:const TextStyle(color:muted,fontSize:12)),
      const SizedBox(height:7),
      Text('${m['homeTeam']?['name']} — ${m['awayTeam']?['name']}',style:const TextStyle(fontWeight:FontWeight.w800)),
      const SizedBox(height:10),
      Row(children:[Container(padding:const EdgeInsets.symmetric(horizontal:12,vertical:8),decoration:BoxDecoration(color:pass?panel2:accent.withOpacity(.14),borderRadius:BorderRadius.circular(10)),child:Text(x['pick'],style:TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:pass?muted:accent))),const SizedBox(width:10),Expanded(child:Text('${x['type']} • ${p.toStringAsFixed(1)}% • Risque ${x['risk']}',style:const TextStyle(color:muted)))]),
      if(x['ai_pick']!=null) ...[const SizedBox(height:10), Container(width:double.infinity,padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:panel2,borderRadius:BorderRadius.circular(10)),child:Text('IA TIPSTER : ${x['ai_pick']} • ${x['ai_reason'] ?? ''}',style:const TextStyle(color:Colors.white,fontSize:12)))]
    ])));
  }

  Widget _performance()=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Performance',style:TextStyle(fontSize:24,fontWeight:FontWeight.w800)),const SizedBox(height:8),const Text('Suivi local des analyses réalisées sur ce téléphone.',style:TextStyle(color:muted)),const SizedBox(height:16),Row(children:[Expanded(child=_metric('Analyses',analysed.toString())),const SizedBox(width:10),Expanded(child:_metric('Résultats',resolved.toString()))]),const SizedBox(height:14),Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(16)),child:const Text('Pour une vraie mesure historique de précision, le backend PREDICT PRO AI v0.2 peut enregistrer et résoudre les prédictions côté serveur. Cette version Android directe garde les clés hors du code source et ne promet aucun gain.',style:TextStyle(color:muted)))]);
  Widget _metric(String a,String b)=>Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(16)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(color:muted)),const SizedBox(height:6),Text(b,style:const TextStyle(fontSize:26,fontWeight:FontWeight.w800,color:accent))]));
  Widget _virtual()=>ListView(padding:const EdgeInsets.all(16),children:[const Text('Virtuel',style:TextStyle(fontSize:24,fontWeight:FontWeight.w800)),const SizedBox(height:10),Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(18)),child:const Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(Icons.smart_toy,color:accent,size:42),SizedBox(height:12),Text('Module virtuel séparé',style:TextStyle(fontSize:20,fontWeight:FontWeight.w800)),SizedBox(height:8),Text('Aucun faux match n’est généré. Une source de jeux virtuels réelle pourra être branchée plus tard.',style:TextStyle(color:muted))])]);

  Future<void> _analyse(Map<String,dynamic> m) async { if(api==null)return; setState(()=>analysed++); showModalBottomSheet(context:context,isScrollControlled:true,backgroundColor:bg,builder:(ctx)=>PredictionSheet(api:api!,match:m)); }
  Widget _error(String s)=>Container(margin:const EdgeInsets.only(bottom:12),padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:danger.withOpacity(.10),borderRadius:BorderRadius.circular(12),border:Border.all(color:danger.withOpacity(.3))),child:Text(s,style:const TextStyle(color:Colors.white)));
  Widget _empty([String text='Aucun match trouvé.'])=>Padding(padding:const EdgeInsets.all(30),child:Center(child:Text(text,style:const TextStyle(color:muted),textAlign:TextAlign.center)));
  String _fmt(DateTime d)=>'${d.day.toString().padLeft(2,'0')}/${d.month.toString().padLeft(2,'0')}/${d.year}';
  String _shortDate(dynamic x){if(x==null)return '';final s=x.toString().replaceAll('T',' ');return s.length>16?s.substring(0,16):s;}
}

class PredictionSheet extends StatefulWidget { final ApiService api; final Map<String,dynamic> match; const PredictionSheet({super.key,required this.api,required this.match}); @override State<PredictionSheet> createState()=>_PredictionSheetState(); }
class _PredictionSheetState extends State<PredictionSheet>{Map<String,dynamic>? result;String? error;String? aiText;int branch=0;String? aiError;bool aiLoading=false;@override void initState(){super.initState();_go();}Future<void>_go()async{try{final h=widget.match['homeTeam']['id'] as int,a=widget.match['awayTeam']['id'] as int;final hh=await widget.api.history(h);final aa=await widget.api.history(a);final r=await PredictionEngine.predict(widget.match,hh,aa);if(mounted)setState(()=>result=r);}catch(e){if(mounted)setState(()=>error=e.toString());}}
Future<void> _askAi() async {
  if (result == null) return;
  final key = await const FlutterSecureStorage().read(key: 'openai_api_key');
  if (key == null || key.isEmpty) {
    if (mounted) setState(() => aiError = 'IA non configurée. Ouvre l’icône ✨ en haut de l’application pour ajouter ta clé OpenAI.');
    return;
  }
  setState(() { aiLoading = true; aiError = null; aiText = null; });
  try {
    final text = await OpenAiService(key).analyseMatch(match: widget.match, prediction: result!);
    if (mounted) setState(() { aiText = text; aiLoading = false; });
  } catch (e) {
    if (mounted) setState(() { aiError = e.toString(); aiLoading = false; });
  }
}

@override Widget build(BuildContext context)=>DraggableScrollableSheet(initialChildSize:.82,maxChildSize:.96,minChildSize:.55,expand:false,builder:(c,sc)=>Container(decoration:const BoxDecoration(color:bg,borderRadius:BorderRadius.vertical(top:Radius.circular(24))),child:ListView(controller:sc,padding:const EdgeInsets.fromLTRB(18,12,18,30),children:[Center(child:Container(width:45,height:4,decoration:BoxDecoration(color:muted,borderRadius:BorderRadius.circular(4)))),const SizedBox(height:18),Text('${widget.match['homeTeam']['name']} — ${widget.match['awayTeam']['name']}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w800)),const SizedBox(height:4),Text('${widget.match['competition']?['name']??''} • ${widget.match['status']??''}',style:const TextStyle(color:muted)),const SizedBox(height:18),if(result==null&&error==null)const Center(child:Padding(padding:EdgeInsets.all(35),child:CircularProgressIndicator())),if(error!=null)Text(error!,style:const TextStyle(color:danger)),if(result!=null)_content(result!,context)])));
Widget _content(Map<String,dynamic>d,BuildContext c)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[_branchSelector(),const SizedBox(height:12),if(branch==0)_fullContent(d,c),if(branch==1)_halfView(d['halves']['first'] as Map<String,dynamic>,d['halves']['expected']['first'] as Map<String,dynamic>,'1ère mi-temps',d['halves']['samples']['first_home'] as num,d['halves']['samples']['first_away'] as num),if(branch==2)_halfView(d['halves']['second'] as Map<String,dynamic>,d['halves']['expected']['second'] as Map<String,dynamic>,'2ème mi-temps',d['halves']['samples']['second_home'] as num,d['halves']['samples']['second_away'] as num),if(branch==3)_statView(d['stats']['yellow'] as Map<String,dynamic>),if(branch==4)_statView(d['stats']['corners'] as Map<String,dynamic>),if(branch==5)_statView(d['stats']['shotsOnTarget'] as Map<String,dynamic>)]);
Widget _branchSelector()=>Container(padding:const EdgeInsets.all(5),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(14)),child:SingleChildScrollView(scrollDirection:Axis.horizontal,child:Row(children:[_branchButton(0,'Match'),_branchButton(1,'1ère MT'),_branchButton(2,'2ème MT'),_branchButton(3,'🟨 Cartons'),_branchButton(4,'🚩 Corners'),_branchButton(5,'🎯 Tirs cadrés')]))) ;
Widget _branchButton(int i,String label)=>Padding(padding:const EdgeInsets.symmetric(horizontal:2),child:GestureDetector(onTap:()=>setState(()=>branch=i),child:AnimatedContainer(duration:const Duration(milliseconds:180),padding:const EdgeInsets.symmetric(vertical:11,horizontal:12),decoration:BoxDecoration(color:branch==i?accent:Colors.transparent,borderRadius:BorderRadius.circular(10)),child:Text(label,textAlign:TextAlign.center,style:TextStyle(fontSize:12,fontWeight:FontWeight.w800,color:branch==i?bg:Colors.white)))));
Widget _halfView(Map<String,dynamic> half,Map<String,dynamic> expected,String title,num homeSamples,num awaySamples){final p=Map<String,dynamic>.from(half['probabilities']);final scores=List<Map<String,dynamic>>.from(half['scores']);final best=half['best'];final bestLabel=best=='home'?'${widget.match['homeTeam']['name']}':best=='away'?'${widget.match['awayTeam']['name']}':'Match nul';return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(16),border:Border.all(color:accent.withOpacity(.25))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title.toUpperCase(),style:const TextStyle(color:accent,fontWeight:FontWeight.w800)),const SizedBox(height:6),Text('Scénario principal : $bestLabel',style:const TextStyle(fontSize:21,fontWeight:FontWeight.w900)),const SizedBox(height:12),_bar('1',p['home'] as num),_bar('X',p['draw'] as num),_bar('2',p['away'] as num)])),const SizedBox(height:12),Row(children:[Expanded(child:_stat('Buts attendus','${(expected['home'] as num).toStringAsFixed(2)} — ${(expected['away'] as num).toStringAsFixed(2)}')),const SizedBox(width:10),Expanded(child:_stat('Historique','${homeSamples.toInt()} / ${awaySamples.toInt()}'))]),const SizedBox(height:12),Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(16)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('Scores probables de la $title'.replaceFirst('de la 2ème','du 2ème'),style:const TextStyle(fontWeight:FontWeight.w800)),const SizedBox(height:10),Wrap(spacing:8,runSpacing:8,children:scores.map((x)=>Chip(label:Text('${x['score']} • ${((x['probability'] as num)*100).toStringAsFixed(1)}%'))).toList())])),const SizedBox(height:12),Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:panel2,borderRadius:BorderRadius.circular(14)),child:const Text('Cette branche utilise les scores de mi-temps disponibles dans l’historique. En LIVE, elle tient compte du score déjà acquis et du temps restant lorsque ces données sont disponibles.',style:TextStyle(color:muted,height:1.4))),const SizedBox(height:10),const Text('Les probabilités restent indicatives : aucune mi-temps ni aucun score exact n’est garanti.',style:TextStyle(color:muted))]);}
Widget _statView(Map<String,dynamic> x){
  final homeName=widget.match['homeTeam']['name']; final awayName=widget.match['awayTeam']['name'];
  final he=(x['homeExpected'] as num).toDouble(), ae=(x['awayExpected'] as num).toDouble();
  final ch=(x['currentHome'] as num).toDouble(), ca=(x['currentAway'] as num).toDouble();
  final live=x['live']==true; final total=(x['totalExpected'] as num).toDouble();
  final leader=x['leader']=='home'?homeName:x['leader']=='away'?awayName:'Égalité';
  final label=x['label'] as String;
  return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(16),border:Border.all(color:accent.withOpacity(.25))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[const Icon(Icons.analytics,color:accent),const SizedBox(width:8),Text(label.toUpperCase(),style:const TextStyle(color:accent,fontWeight:FontWeight.w800)),if(live)...[const Spacer(),Container(padding:const EdgeInsets.symmetric(horizontal:8,vertical:4),decoration:BoxDecoration(color:danger.withOpacity(.15),borderRadius:BorderRadius.circular(8)),child:const Text('LIVE',style:TextStyle(color:danger,fontWeight:FontWeight.w800,fontSize:11)))] ]),
      const SizedBox(height:14),
      Row(children:[Expanded(child:Text('$homeName\n${live?ch.toStringAsFixed(0):he.toStringAsFixed(1)}',style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900))),const Text('VS',style:TextStyle(color:muted)),Expanded(child:Text('$awayName\n${live?ca.toStringAsFixed(0):ae.toStringAsFixed(1)}',textAlign:TextAlign.right,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900)))]),
      const SizedBox(height:12),
      _bar(homeName,(he/(he+ae==0?1:he+ae))),_bar(awayName,(ae/(he+ae==0?1:he+ae))),
    ])),
    const SizedBox(height:12),
    Row(children:[Expanded(child:_stat('Total attendu',total.toStringAsFixed(1))),const SizedBox(width:10),Expanded(child:_stat('Avantage statistique',leader))]),
    const SizedBox(height:12),
    Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:panel2,borderRadius:BorderRadius.circular(14)),child:Text(live?'En LIVE, les valeurs actuelles sont affichées et l’estimation restante est recalculée selon la minute du match.':'Cette branche estime le volume attendu à partir des statistiques disponibles dans l’historique des deux équipes.',style:const TextStyle(color:muted,height:1.4))),
    const SizedBox(height:10),
    Text('Échantillon historique : ${x['homeSample'].toInt()} matchs / ${x['awaySample'].toInt()} matchs',style:const TextStyle(color:muted,fontSize:12)),
    const SizedBox(height:6),
    const Text('Les valeurs sont des estimations statistiques et ne garantissent pas le nombre réel d’événements.',style:TextStyle(color:muted)),
  ]);
}
Widget _fullContent(Map<String,dynamic>d,BuildContext c){final con=Map<String,dynamic>.from(d['consensus']);final best=d['best'];final label=best=='home'?widget.match['homeTeam']['name']:best=='away'?widget.match['awayTeam']['name']:'Match nul';final scores=List<Map<String,dynamic>>.from(d['exact_scores']);return Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(16)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('CONSENSUS',style:TextStyle(color:accent,fontWeight:FontWeight.w800)),const SizedBox(height:6),Text(label,style:const TextStyle(fontSize:26,fontWeight:FontWeight.w900)),Text('Confiance calculée : ${(d['confidence']*100).toStringAsFixed(1)}%',style:const TextStyle(color:muted)),const SizedBox(height:14),_bar('1',con['home'] as num),_bar('X',con['draw'] as num),_bar('2',con['away'] as num)])),const SizedBox(height:12),Row(children:[Expanded(child:_stat('Buts attendus','${(d['expected_goals']['home'] as num).toStringAsFixed(2)} — ${(d['expected_goals']['away'] as num).toStringAsFixed(2)}')),const SizedBox(width:10),Expanded(child:_stat('Historique','${d['samples']['home'].toInt()} / ${d['samples']['away'].toInt()}'))]),const SizedBox(height:12),Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(16)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Scores exacts les plus probables',style:TextStyle(fontWeight:FontWeight.w800)),const SizedBox(height:10),Wrap(spacing:8,runSpacing:8,children:scores.map((s)=>Chip(label:Text('${s['score']} • ${((s['probability'] as num)*100).toStringAsFixed(1)}%'))).toList())])),const SizedBox(height:12),
Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(16),border:Border.all(color:accent.withOpacity(.25))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
const Row(children:[Icon(Icons.auto_awesome,color:accent),SizedBox(width:8),Text('IA PREDICT PRO AI',style:TextStyle(color:accent,fontWeight:FontWeight.w800))]),
const SizedBox(height:8),
const Text('L’IA explique les données du moteur statistique. Elle ne remplace pas les calculs et ne garantit jamais un résultat.',style:TextStyle(color:muted)),
const SizedBox(height:10),
if(aiLoading)const Row(children:[SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)),SizedBox(width:10),Text('Analyse IA en cours…')]),
if(!aiLoading)FilledButton.icon(onPressed:_askAi,icon:const Icon(Icons.auto_awesome),label:Text(aiText==null?'Demander l’analyse IA':'Regénérer l’analyse IA')),
if(aiError!=null)Padding(padding:const EdgeInsets.only(top:8),child:Text(aiError!,style:const TextStyle(color:danger))),
if(aiText!=null)Padding(padding:const EdgeInsets.only(top:12),child:SelectableText(aiText!,style:const TextStyle(height:1.45))),
]),),
const SizedBox(height:12),const Text('Modèles',style:TextStyle(fontSize:18,fontWeight:FontWeight.w800)),const SizedBox(height:8),...Map<String,dynamic>.from(d['models']).entries.map((e){final v=Map<String,dynamic>.from(e.value);return Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(e.key.replaceAll('_',' '),style:const TextStyle(fontWeight:FontWeight.w800)),Text('1 ${((v['home'] as num) * 100).toStringAsFixed(1)}%  •  X ${((v['draw'] as num) * 100).toStringAsFixed(1)}%  •  2 ${((v['away'] as num) * 100).toStringAsFixed(1)}%',style:const TextStyle(color:muted))])));}),const SizedBox(height:10),const Text('Les probabilités sont statistiques et le score exact n’est jamais garanti.',style:TextStyle(color:muted))]);}
Widget _bar(String l,num v)=>Padding(padding:const EdgeInsets.only(bottom:8),child:Column(children:[Row(children:[Text(l),const Spacer(),Text('${(v.toDouble()*100).toStringAsFixed(1)}%')]),const SizedBox(height:4),ClipRRect(borderRadius:BorderRadius.circular(5),child:LinearProgressIndicator(value:v.toDouble().clamp(0,1),minHeight:7,backgroundColor:panel2,valueColor:const AlwaysStoppedAnimation(accent)))]));
Widget _stat(String a,String b)=>Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(14)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(a,style:const TextStyle(color:muted)),const SizedBox(height:5),Text(b,style:const TextStyle(fontWeight:FontWeight.w800))]);
}
